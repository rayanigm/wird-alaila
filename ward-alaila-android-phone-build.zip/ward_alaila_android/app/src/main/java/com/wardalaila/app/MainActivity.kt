package com.wardalaila.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Deep = Color(0xFF081B16)
private val Panel = Color(0xFF12372B)
private val Gold = Color(0xFFE2C477)
private val Cream = Color(0xFFF4F0E5)
private val Muted = Color(0xFFB7C8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WardApp() }
    }
}

@Composable
fun WardApp() {
    var page by remember { mutableStateOf("الرئيسية") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Deep, surface = Panel, primary = Gold,
        onBackground = Cream, onSurface = Cream, onPrimary = Deep
    )) {
        Scaffold(
            containerColor = Deep,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D261E), contentColor = Gold) {
                    val items = listOf("الرئيسية", "قراءاتي", "الغرفة", "حسابي")
                    val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Groups, Icons.Default.Person)
                    items.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = page == label,
                            onClick = { page = label },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Panel, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (page) {
                    "الرئيسية" -> HomeScreen(onOpen = { page = it })
                    "قراءاتي" -> SimpleScreen("قراءاتي", "سجل الورد اليومي والإحصائيات ديالك غادي يبان هنا.")
                    "الغرفة" -> SimpleScreen("غرفة العائلة", "إنشاء غرفة عائلية أو الانضمام باستعمال كود الغرفة.")
                    "حسابي" -> AccountScreen()
                    else -> SimpleScreen(page, "هاد القسم غادي نكملوه فالمرحلة الجاية.")
                }
            }
        }
    }
}

@Composable
fun BrandHeader() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("ورد العائلة", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("للتعاون على كتاب الله", color = Muted, fontSize = 13.sp)
        }
        Surface(shape = RoundedCornerShape(18.dp), color = Panel) {
            Icon(Icons.Default.AutoAwesome, null, tint = Gold, modifier = Modifier.padding(14.dp).size(28.dp))
        }
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    BrandHeader()
    Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("السلام عليكم 👋", color = Muted, fontSize = 14.sp)
            Text("مرحبا بك في ورد العائلة", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Text("وردك اليومي", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("بدا رحلتك مع القرآن والذكر اليوم", color = Muted, fontSize = 13.sp)
            LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Color(0xFF315747))
            Text("0% مكتمل", color = Gold, fontSize = 12.sp)
        }
    }
    Text("أقسام التطبيق", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    val sections = listOf(
        Triple("القرآن الكريم", "114 سورة • فهرس وبحث", Icons.Default.MenuBook),
        Triple("الأحاديث النبوية", "صحيح البخاري وصحيح مسلم", Icons.Default.Book),
        Triple("الأذكار والسبحة", "الصباح والمساء والنوم", Icons.Default.Favorite),
        Triple("ختمة القرآن", "تتبع الأجزاء والتقدم", Icons.Default.AutoStories),
        Triple("مواقيت الصلاة", "حسب المدينة", Icons.Default.Mosque),
        Triple("التقويم الهجري", "المناسبات والتواريخ", Icons.Default.CalendarMonth),
        Triple("تحديات العائلة", "أهداف إيمانية مشتركة", Icons.Default.EmojiEvents),
        Triple("المساعد الذكي", "مساعدة ومعلومات بمصادر", Icons.Default.SmartToy)
    )
    sections.chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            pair.forEach { (title, subtitle, icon) ->
                Surface(
                    color = Panel, shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.weight(1f).clickable { onOpen(title) }
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(icon, null, tint = Gold, modifier = Modifier.size(25.dp))
                        Text(title, color = Cream, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(subtitle, color = Muted, fontSize = 11.sp)
                    }
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun SimpleScreen(title: String, description: String) {
    BrandHeader()
    Text(title, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
        Text(description, color = Cream, modifier = Modifier.padding(18.dp), lineHeight = 25.sp)
    }
    Text("هاد النسخة هي الهيكل الأولي للواجهة. المحتوى الحقيقي والمزامنة غادي يتربطو فالمرحلة الجاية.", color = Muted, fontSize = 12.sp)
}

@Composable
fun AccountScreen() {
    BrandHeader()
    Text("الحساب ديالك", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("تسجيل الدخول", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("سجّل الدخول بحساب Google باش تحفظ الحساب ديالك وتدخل لغرفة العائلة من أجهزة مختلفة.", color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
            Button(onClick = { }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Deep)) {
                Icon(Icons.Default.AccountCircle, null)
                Spacer(Modifier.width(8.dp))
                Text("المتابعة باستخدام Google", fontWeight = FontWeight.Bold)
            }
            Text("ملاحظة: زر Google هنا واجهة أولية فقط؛ خاص إعداد Firebase وربط OAuth قبل ما يخدم تسجيل الدخول الحقيقي.", color = Muted, fontSize = 11.sp)
        }
    }
}
